// Functional component with Anonymous Function
import React from 'react';

const Footer = () => {
  //const copyrightYear = 2023;

  // return JSX
  return (
    <><footer className='text-center'>
      <hr />

      <p className="red-text green-text footer-purple-text">
        Copyright 2023 | Asmita</p>
    </footer>
    <p className='text-center'>Built with Passion in Jan 2023</p></>
  );
};

// Specifies the default values for props:
// eslint-disable-next-line no-lone-blocks


export default Footer;