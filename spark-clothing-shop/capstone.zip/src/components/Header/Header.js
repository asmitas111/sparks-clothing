import React from 'react';
import { Link } from 'react-router-dom';
import image1 from '../../Assets/images/LOGO.jpg';
import Navbar from '../Navbar/Navbar';


function Header() {

  //must return JSX
  return (
    <header>
      <nav className="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
          <img src={image1} alt="london" width="100" />
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarCollapse"
            aria-controls="navbarCollapse"
            aria-expanded="false"
            aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarCollapse">
            <Navbar />
            <button className="btn btn-danger">
              cart
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Header;
