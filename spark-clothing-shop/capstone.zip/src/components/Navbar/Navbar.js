// Functional Component with Arrow Function
import React from 'react';
import { NavLink } from 'react-router-dom';

import contact from '../../Assets/icons/ContactUs.png';
import home from '../../Assets/icons/Home.png';
import product from '../../Assets/icons/Product.png';

const Navbar = () => {
  
const mnlst = [
  {
    id:1,
    url:'/product',
    title:'Product',
    src:{product},
    alt:'product'
  },
  {
    id:2,
    url:'/about',
    title:'About Us',
    src:'./Assets/icons/AboutUs.png',
    alt:'about'
  },
  {
    id:3,
    url:'/contact-us',
    title:'Contact Us',
    src:{contact},
    alt:'contact'
  },
];

  return (
    <ul className="navbar-nav me-auto mb-2 mb-md-0">
      <li className="nav-item">
        <NavLink to="/" className="nav-link active" aria-current="page">
        <img src={home} alt="home" width="100" />
        </NavLink>
      </li>
      {mnlst.map(({id, url, title, src, alt}) => {
        return (
        <li className="nav-item" key={id}>
        <NavLink to={url} className="nav-link" activeclassname="active">
        <img src={src} alt={alt} width="100" />
        </NavLink>
      </li>
      );
    })}
    </ul>
  );
};

export default Navbar;
