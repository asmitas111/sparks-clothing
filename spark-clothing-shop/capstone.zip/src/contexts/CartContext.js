// step1: create context
// For step 2: Ref App.js
import { createContext } from 'react';

export const CartContext = createContext();