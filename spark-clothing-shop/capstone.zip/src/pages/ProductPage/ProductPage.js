import React, { useEffect, useState } from "react";
import { fetchApi } from "../../utils/fetchApi";
import { NavLink, useLocation } from "react-router-dom";
import { Helmet } from "react-helmet";
//import { CartContext } from "../../contexts/CartContext";
import men from "../../Assets/carousel/MenCarousel.jpg";
import women from "../../Assets/carousel/WomenCarousel.jpg";
import kid from "../../Assets/carousel/KidCarousel.jpg";

const useQuery = () => new URLSearchParams(useLocation().search);
const ProductPage = () => {
 // const cartData = useContext(CartContext);
 // console.log(cartData.cartDispatch);

  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [product, setProduct] = useState([]);

  let url = null;
  let query = useQuery();
  let queryParam = query.get("category");

  if (queryParam === "mens-clothing") {
    url = "http://localhost:3000/product?category=mens-clothing";
  } else if (queryParam === "womens-clothing") {
    url = "http://localhost:3000/product?category=womens-clothing";
  } else if (queryParam === "kids-clothing") {
    url = "http://localhost:3000/product?category=kids-clothing";
  } else {
    url = "http://localhost:3000/product";
  }

  useEffect(() => {
    //afer initial rendering this will be called. II ideal hook for us to send req to rest api
    // whai is the api url (https://jsonplaceholder.typicode.com/users)
    // what is the http method? GET // what is the rest api clint tool? fetch api

    fetchApi(url)
      .then((resInJson) => {
        if (resInJson.status !== 404){
        setIsLoading(false);
        setIsError(false);
        setProduct(resInJson);
        }  else {
          setIsLoading(false);
           setIsError(true);
           setProduct([]); }
      })

      .catch((err) => {
        // if error occurs
        console.log(err);
        setIsLoading(false);
        setIsError(true);
        setProduct([]);
      })
      .finally(() => {
        console.log("It is over");
      });
  }, [url]);

  if (isLoading) {
    return (
      <div className="text-center">
        <div className="spinner-border text-danger" role="status"></div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="alert alert-danger">
        Sorry! Unable to fetch users! Try again.
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Products</title>
      </Helmet>
      <div
        id="carouselExampleDark"
        className="carousel carousel-dark slide"
        data-bs-ride="carousel"
      >
        <div className="carousel-inner">
          <div className="carousel-item active" data-bs-interval={3000}>
            <img
              src={men}
              className="text-center"
              alt="..."
            />
          </div>
          <div className="carousel-item" data-bs-interval={3000}>
            <img
              src={women}
              className="text-center"
              alt="..."
            />
          </div>
          <div className="carousel-item" data-bs-interval={3000}>
            <img
              src={kid}
              className="text-center"
              alt="..."
            />
          </div>
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleDark"
          data-bs-slide="prev"
        >
          <span className="carousel-control-prev-icon" aria-hidden="true" />
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleDark"
          data-bs-slide="next"
        >
          <span className="carousel-control-next-icon" aria-hidden="true" />
          <span className="visually-hidden">Next</span>
        </button>
        <div className="carousel-indicators">
          <button
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide-to={0}
            className="active"
            aria-current="true"
            aria-label="Slide 1"
          />
          <button
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide-to={1}
            aria-label="Slide 2"
          />
          <button
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide-to={2}
            aria-label="Slide 3"
          />
        </div>
      </div>
      <div className="text-center" >
        <NavLink
          to="/product?category=mens-clothing"
          className="nav-link m-3 text-styling"
        >
          MEN
        </NavLink>
        <NavLink
          to="/product?category=womens-clothing"
          className="nav-link m-3 text-styling"
        >
          WOMEN
        </NavLink>
        <NavLink
          to="/product?category=kids-clothing"
          className="nav-link m-3 text-styling"
        >
          KID
        </NavLink>
      </div>
      <div className="row mt-1">
        
        {product.map(
          ({
            id,
            src,
            alt,
            title,
            description,
            likes,
            price,
            originalCost,
            discount,
            ratings,
          }) => {
              return (
                <div className="col-md-3 mt-3" key={id}>
                  <div className="card shadow-sm border-removal">
                    <div className="position-relative">
                      <NavLink
                        className="nav-link active"
                        aria-current="page"
                        to="/product/feedback"
                      >
                        <img src={src} alt={alt} width={259} />
                      </NavLink>
                      <div className="position-absolute bottom-0 start-0 ">

                        <p className="rating" style={{ background: "lightgrey" }}>
                          {likes}
                          <svg
                            xmlns="http://www.w3.org/2000/svg"
                            width={14}
                            height={13}
                            fill="currentColor"
                            className="bi bi-star-fill mb-1"
                            viewBox="7 1 1 16"
                          >
                            {<path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z" />}
                          </svg>
                          | {ratings}
                        </p>
                      </div>
                    </div>
                    <div className="card-body">
                      <p className="card-text m-0">{title}</p>
                      <p style={{ color: "grey" }} className="pt-0">
                        {description}
                      </p>
                      <div>
                        <span>{price} </span>
                        <span
                          style={{
                            color: "grey",
                            textDecorationLine: "line-through",
                          }}
                        >
                          {originalCost}
                        </span>
                        <span style={{ color: "red" }}>{discount}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            }
        )}
      </div>
    </>
  );
};

export default ProductPage;
