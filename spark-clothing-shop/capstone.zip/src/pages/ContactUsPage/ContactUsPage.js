import axios from 'axios';
import React, { useState } from 'react'; 
import logo from '../../Assets/images/contact.png';

const ContactUsPage = () => {
  const [isSaved, setIsSaved] = useState(false);
  const [getInTouch, setGetInTouch] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  const handleChange = event => {
      setGetInTouch({
      ...getInTouch,
      [event.target.name]: event.target.value
    });
  };

  const handleSubmit = event => {
    event.preventDefault();
    // Add the getInTouch data to the products JSON file
    // ...
    setIsSaved(true);
    axios
      .post('http://localhost:3000/profile', getInTouch)
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  return (
    <div className="contact-page">
      <img src={logo} alt="Company Logo" />
      
      <hr />
      <h2>Get In Touch</h2>
      <form 
        className="col-md-3"
        onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Name"
          value={getInTouch.name}
          onChange={handleChange}
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={getInTouch.email}
          onChange={handleChange}
        />
        <input
          type="tel"
          name="phone"
          placeholder="Phone"
          value={getInTouch.phone}
          onChange={handleChange}
        />
        <textarea
          name="message"
          placeholder="Message"
          value={getInTouch.message}
          onChange={handleChange}
        />
         <div className="mt-3">
          <button type="submit" className="btn btn-primary" disabled={getInTouch.name === ''}>
            Submit
          </button>
          <div>
            {isSaved ? (
              <div data-testid="isSaved" className="alert alert-success">
                Saved Successfully
              </div>
            ) : (
              ''
            )}
          </div>
        </div>
      </form>
    </div>
  );
};

export default ContactUsPage;